package Main;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import java.awt.*;
import java.awt.event.*;

public class shoutcutKey {
    private static shoutcutKey my_shoutcutKey = new shoutcutKey();
    noteFrame cur_nf = noteFrame.getInstance();
    Robot rbt;
    private char prev = 0;
    private boolean cpy_line = false;
    public shoutcutKey() {
    }
    JTextArea jta = cur_nf.getJta();
    public void addkeylistener() {
        jta.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                System.out.println(prev);
                try {
                    rbt = new Robot();
                } catch (AWTException ex) {
                    ex.printStackTrace();
                }
                int offset = jta.getCaretPosition();
                int totalLineCount = jta.getLineCount();
                int row = 0;
                try {
                    row = jta.getLineOfOffset(offset);
                } catch (BadLocationException ex) {
                    ex.printStackTrace();
                }
                int line_start = 0;
                int line_end = 0;
                int column = 0;
                try {
                    line_start = jta.getLineStartOffset(row);
                } catch (BadLocationException ex) {
                    ex.printStackTrace();
                }
                try {
                    line_end = jta.getLineEndOffset(row);
                } catch (BadLocationException ex){
                    ex.printStackTrace();
                }
                column = offset - line_start;

                // mode change
                if(e.isControlDown()){
                    if(e.getKeyCode() == KeyEvent.VK_0){
                        jta.setEditable(false);
                        cur_nf.setM_mode(true);
                    }
                    else if(e.getKeyCode() == KeyEvent.VK_1){
                        jta.setEditable(false);
                        cur_nf.setASCII_mode(true);
                    }
                }
                else if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
                    jta.setEditable(true);
                    cur_nf.setM_mode(false);
                    cur_nf.setASCII_mode(false);
                }
                // M_mode shoutCut
                else if(cur_nf.isM_mode()){
                    // left
                    if(e.getKeyCode() == KeyEvent.VK_H){
                        jta.setCaretPosition(offset-1);
                    }
                    // right
                    else if(e.getKeyCode() == KeyEvent.VK_L){
                        jta.setCaretPosition(offset+1);
                    }
                    // down
                    else if(e.getKeyCode() == KeyEvent.VK_J){
                        rbt.keyPress(KeyEvent.VK_DOWN);
                    }
                    // up
                    else if(e.getKeyCode() == KeyEvent.VK_K){
                        rbt.keyPress(KeyEvent.VK_UP);
                    }
                    // copy current line
                    else if(e.getKeyCode() == KeyEvent.VK_Y){
                        if(prev == 'y'){
                            cpy_line = true;
                            jta.setSelectionStart(line_start);
                            jta.setSelectionEnd(line_end);
                            jta.copy();
                        }
                        else {
                            cpy_line = false;
                            jta.copy();
                        }
                        jta.setCaretPosition(jta.getCaretPosition());
                    }
                    // paste
                    else if(e.getKeyCode() == KeyEvent.VK_P){
                        jta.setEditable(true);
                        System.out.println(cpy_line);
                        if(cpy_line) {
                            jta.setCaretPosition(line_end);
                        }
                        jta.paste();
                        jta.setEditable(false);
                    }
                    // delete
                    else if(e.getKeyCode() == KeyEvent.VK_D){
                        jta.setEditable(true);
                        if(prev == 'd'){
                            cpy_line = true;
                            jta.setSelectionStart(line_start);
                            jta.setSelectionEnd(line_end);
                            jta.cut();
                        }
                        else {
                            cpy_line = true;
                            jta.cut();
                        }
                        jta.setEditable(false);
                    }
                }
//                // ASCII mode
//                else if(cur_nf.isASCII_mode()){
//                    char ch = e.getKeyChar();
//
//
//                }

                prev = e.getKeyChar();
            }


            @Override
            public void keyReleased(KeyEvent e) {
            }
        });
    }

    public static shoutcutKey getInstance(){
        return my_shoutcutKey;
    }


}
