package Main;

import javax.swing.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class stastic {

    public stastic() {
    }

    public int count(String str) {
        String dest = "";

        if(str != null){
            Pattern p = Pattern.compile("\\s*|\t|\r|\n");
            Matcher m = p.matcher(str);
            dest = m.replaceAll("");
        }

        int len = dest.length();
        return len;
    }


}
