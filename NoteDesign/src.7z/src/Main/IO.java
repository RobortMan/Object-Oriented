package Main;


import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.*;

public class IO {
    private static IO theIO = new IO();
    private page mainPage = new page();
    private noteFrame ntf = noteFrame.getInstance();
    private myNote edp = myNote.getInstance();
    private NoteList notelist;
    private static IO iot=new IO();
    private FileOutputStream fos;//文件输出流
    private OutputStreamWriter osr;
    private FileInputStream fis;//文件输入流
    private InputStreamReader isr;
    private FileOutputStream fos_his;//文件输出流
    private OutputStreamWriter osr_his;
    private FileInputStream fis_his;//文件输入流
    private InputStreamReader isr_his;
    private JFileChooser jfc = myNote.getJfc();
    private String ext="";
    private static String his_path = "C:\\Users\\Allie人民的艾力\\Documents\\Hisory";


    public IO() {
    }

    public void newFile(String path) {
        ntf = noteFrame.getInstance();
        page new_page = new page();
        history new_his = new history();
        ntf.setMy_page(new_page);
        try {
            jfc.showDialog(null, "新建");
            if(jfc.getFileFilter()== myNote.getTxtFilter()){
                ext=".txt";
            }else{
                ext=".edt";
            }
            path = jfc.getSelectedFile().getAbsolutePath() + ext;
            new_his.setPath(path);
            int ind_path = path.lastIndexOf('\\');
            String name = path.substring(ind_path+1);
            new_his.setName(name);
            fos=new FileOutputStream(path);
            osr=new OutputStreamWriter(fos);
            ntf.getJmtFiles(2).setEnabled(true);
            ntf.getJta().setText("");
            notelist.addHis(new_his);
        } catch (IOException e1) {
            JOptionPane.showMessageDialog(null, "文件新建错误");
        } catch (Exception e2) {
        }
        ntf.setCur_his(new_his);
    }

    public void openFile() {
        fis=null;
        isr=null;
        page open_page;
        history open_his = new history();
        char[] buffer = new char[1024];
        StringBuffer sb = new StringBuffer();
        ntf = noteFrame.getInstance();
        int num = 0;
        try {
            jfc.setFileSelectionMode(JFileChooser.FILES_ONLY);
            jfc.showOpenDialog(null);

            fis = new FileInputStream(jfc.getSelectedFile().getAbsolutePath());
            String path = jfc.getSelectedFile().getAbsolutePath();
            System.out.println(path);
            int ind_path = path.lastIndexOf('\\');
            String name = path.substring(ind_path+1);
            open_his.setName(name);
            open_his.setPath(path);
            isr = new InputStreamReader(fis);
            while((num=isr.read(buffer))>0){
                for (int i = 0; i < num; i++) {
                    sb.append(buffer[i]);
                }
            }
            String contend = sb.toString();
            System.out.println(contend);

            open_page = JSON.parseObject(contend, page.class);
            ntf.setMy_page(open_page);
            ntf.setCur_his(open_his);

            ntf.getJta().setText(open_page.getMainBuffer());


            ntf.getJmtFiles(2).setEnabled(true);
            notelist.addHis(open_his);

        } catch (FileNotFoundException e1) {
            JOptionPane.showMessageDialog(null, "找不到该文件");
        } catch (IOException e1) {
            JOptionPane.showMessageDialog(null, "文件读取错误");
        } catch (Exception e2) {
        } finally {
            try {
                fis.close();
                isr.close();
            } catch (IOException e1) {
                JOptionPane.showMessageDialog(null, "文件无法关闭");
            } catch (Exception e2) {
            }
        }
    }

    public void saveFile(String path) {
        history save_his = noteFrame.getInstance().getCur_his();
        page save_page = noteFrame.getInstance().getMy_page();
        try {
            path = save_his.getPath();
            fos=new FileOutputStream(path);
            osr=new OutputStreamWriter(fos);
            String content = JSON.toJSONString(save_page);
            System.out.println(content);
            save_his.setTime(1);
            osr.write(content);
            osr.flush();
            ntf.setIsSaved(true);
            notelist.addHis(save_his);
        } catch (IOException e1) {
            JOptionPane.showMessageDialog(null, "文件保存错误");
        } catch (Exception e) {
        } finally {
            try {
                fos.close();
                osr.close();
            } catch (IOException e1) {
                JOptionPane.showMessageDialog(null, "文件无法关闭");
            } catch (Exception e2) {
            }
        }
    }

    public void saveFileAs() {
        history save_his = noteFrame.getInstance().getCur_his();
        page save_page = noteFrame.getInstance().getMy_page();
        try {
            jfc.showDialog(null, "另存为");
            String path = jfc.getSelectedFile().getAbsolutePath();
            int ind_path = path.lastIndexOf('\\');
            String name = path.substring(ind_path+1);
            save_his.setPath(path);
            save_his.setName(name);
            if(jfc.getFileFilter()== edp.getTxtFilter()){
                ext=".txt";
                fos=new FileOutputStream(path + ext);
            } else{
                ext=".java";
                fos=new FileOutputStream(path + ext);
            }
            osr = new OutputStreamWriter(fos);
            osr=new OutputStreamWriter(fos);
            String content = JSON.toJSONString(save_page);
            save_his.setTime(1);
            osr.write(content);
            osr.flush();
            ntf.setIsSaved(true);
        } catch (IOException e1) {
            JOptionPane.showMessageDialog(null, "文件保存错误");
        } catch (Exception e) {
        } finally {
            try {
                fos.close();
                osr.close();
            } catch (IOException e1) {
                JOptionPane.showMessageDialog(null, "文件无法关闭");
            } catch (Exception e2) {
            }
        }
    }

    public NoteList getNotelist() {
        return notelist;
    }

    public void setNotelist(NoteList notelist) {
        this.notelist = notelist;
    }

    public static IO getInstance() {
        return theIO;
    }

}








