package Main;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;

public class NoteList {

        NoteList(){
        }

        @JSONField(name = "LIST")
        private List<history> HistoryList;

        void addHis(history newhis){
            HistoryList.add(newhis);
        }

        private void delete(int i){
            HistoryList.remove(i);
        }

        public List<history> getHistoryList() {
            return HistoryList;
        }

        public void setHistoryList(List<history> historyList) {
            HistoryList = historyList;
        }


}
