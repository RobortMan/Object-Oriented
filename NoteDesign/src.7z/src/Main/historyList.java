package Main;

import com.alibaba.fastjson.JSON;

import javax.swing.*;
import java.awt.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class historyList extends JFrame {
    private Dimension dim;
    private JPanel p1,p2,p3;
    private JLabel list, index_l;
    private JButton confirm;
    private JTextArea his_jta;
    private JTextField index_jta;
    private String index_str;
    private noteFrame ntf = noteFrame.getInstance();
    private myNote mynote = myNote.getInstance();
    private FileInputStream fis;//文件输入流
    private InputStreamReader isr;

    private static String his_path = "C:\\Users\\Allie人民的艾力\\Documents\\Hisory";

    public historyList(){
        super("历史记录");
        dim = this.getToolkit().getScreenSize();
        this.setSize(dim.width / 2, dim.height * 2/ 3);
        this.setLayout(new GridLayout(1, 1));
        this.initComponents();
        this.addActionListeners();
        this.setLocationRelativeTo(null);
//        this.setResizable(false);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        this.setVisible(true);
    }

    private void addActionListeners() {
    }

    private void initComponents() {
        NoteList notelist = IO.getInstance().getNotelist();
        for(int i=0;i< notelist.getHistoryList().size();i++){
            history his = notelist.getHistoryList().get(i);
            his_jta.append(i+"."+ his.getName() +"\n");
        }

        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        index_l = new JLabel("输入笔记号：");
        his_jta = new JTextArea(40,30) ;
        index_jta = new JTextField(5);
        confirm = new JButton("确认");
        his_jta.setEditable(false);
        his_jta.setLineWrap(true);
//        his_jta.setSize(100,300);
        his_jta.setOpaque(true);
        p2.add(index_l);
        p2.add(index_jta);
        p2.add(confirm);
        this.getContentPane().add(new JScrollPane(his_jta));
        this.getContentPane().add(p2);
    }

}
