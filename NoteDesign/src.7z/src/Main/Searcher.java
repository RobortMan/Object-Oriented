package Main;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;

class Searcher extends JFrame {
    /**
     * @author Aili
     */
    private static final long serialVersionUID = 1L;
    private Dimension dim;
    private JPanel p1, p2, p3;
    private JLabel search, replace;
    private JTextField jtf1, jtf2;
    private JButton replace_con;
    private String source, target;
    private noteFrame ntf = noteFrame.getInstance();
    DefaultHighlighter.DefaultHighlightPainter p = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);

    public Searcher() {
        super("查找/替换");
        dim = this.getToolkit().getScreenSize();
        this.setSize(dim.width / 4, dim.height / 4);
        this.setLayout(new GridLayout(3, 1));
        this.initComponents();
        this.addActionListeners();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        this.setVisible(true);
    }

    private void initComponents() {
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        search = new JLabel("查找：");
        replace = new JLabel("替换：");
        jtf1 = new JTextField(30);
        jtf2 = new JTextField(30);
        replace_con = new JButton("替换");
        p1.setLayout(new FlowLayout());
        p2.setLayout(new FlowLayout());
        p3.setLayout(new FlowLayout());
        p1.add(search);
        p1.add(jtf1);
        p2.add(replace);
        p2.add(jtf2);
        p3.add(replace_con);
        this.getContentPane().add(p1);
        this.getContentPane().add(p2);
        this.getContentPane().add(p3);
    }

    private void addActionListeners() {
        replace_con.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                source = jtf1.getText();
                target = jtf2.getText();
                if (ntf.getJta().getText().contains(source)) {
                    String result = ntf.getJta().getText().replace(source, target);
                    ntf.getJta().setText(result);
                }
            }
        });
        jtf1.getDocument().addDocumentListener(new DocumentListener() {
            @Override

            public void insertUpdate(DocumentEvent e) {
                source = jtf1.getText();
                Highlighter highlighter = ntf.getJta().getHighlighter();
                highlighter.removeAllHighlights();
                int index = 0;

                int sum_i = 0;
                while (ntf.getJta().getText().substring(sum_i).contains(source) && source.length() != 0) {
                    System.out.println(ntf.getJta().getText().substring(sum_i));
                    index = ntf.getJta().getText().substring(sum_i).indexOf(source);
                    System.out.println(sum_i);
                    try {
                        highlighter.addHighlight(sum_i+index, sum_i +index+ source.length(), p);
                    } catch (BadLocationException ex) {
                        ex.printStackTrace();
                    }
                    sum_i = sum_i + index + source.length();

                }

            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                source = jtf1.getText();
                Highlighter highlighter = ntf.getJta().getHighlighter();
                highlighter.removeAllHighlights();
                int index = 0;

                int sum_i = 0;
                while (ntf.getJta().getText().substring(sum_i).contains(source) && source.length()!=0) {
                    System.out.println(ntf.getJta().getText().substring(sum_i));
                    index = ntf.getJta().getText().substring(sum_i).indexOf(source);
                    System.out.println(sum_i);
                    try {
                        highlighter.addHighlight(sum_i+index, sum_i +index+ source.length(), p);
                    } catch (BadLocationException ex) {
                        ex.printStackTrace();
                    }
                    sum_i = sum_i + index + source.length();
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {

            }
        });
    }
}
