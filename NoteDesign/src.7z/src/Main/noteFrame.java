package Main;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.Highlighter;
import javax.swing.undo.UndoManager;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.WindowEvent;

public class noteFrame extends JFrame implements ActionListener {
    static noteFrame cur_noteframe = new noteFrame();
    private page my_page;
    private history cur_his = new history();
    private String path;

    private JMenuBar jmb;
    private JMenu jmFile, jmEdit, jmHelp, jmTool;
    private JMenuItem jmtAbout, jmtFiles[], jmtEdits[];

    private JToolBar jtb;   //工具条
    private JCheckBox jcbBold, jcbItalic;
    private JPanel p1, p2, p3;
    private JComboBox<String> jcbFont, jcbSize;
    private JLabel jlFont,jlSize, jlStyle, jlColor,jlStastic;
    private JButton jbColor, jbClear;
    private Container ct;

    private JTextArea jta;
    private JCheckBoxMenuItem jmtLineWrap, jmtTool;          // 复选菜单项
    private ImageIcon content_bg, header_bg;
    private Robot rbt;
    // 基础变量
    private Font font;
    private Color color, backgroudColor;
    private int fontSize, textSize = 0;
    private long fileSize;
    private Dimension dim;
    private int[] fontStyle = new int[2];
    private int style;
    UndoManager undoManager = new UndoManager();

    private boolean M_mode = false;
    private boolean ASCII_mode = false;
    private boolean Reading_file = false;

    public history getCur_his() {
        return cur_his;
    }

    public void setCur_his(history cur_his) {
        this.cur_his = cur_his;
    }

    public page getMy_page() {
        return my_page;
    }

    public void setMy_page(page cur_page) {
        System.out.println("flag0");
        this.my_page.setFontFamily(cur_page.getFontFamily());
        this.my_page.setMainBuffer(cur_page.getMainBuffer());
        this.my_page.setFontSize(cur_page.getFontSize());
        this.my_page.setFontColor(cur_page.getFontColor());
        this.my_page.setFontStyle(cur_page.getFontStyle());
        System.out.println("flag1");


    }

    public boolean isM_mode() {
        return M_mode;
    }

    public void setM_mode(boolean m_mode) {
        M_mode = m_mode;
    }

    public boolean isASCII_mode() {
        return ASCII_mode;
    }

    public void setASCII_mode(boolean ASCII_mode) {
        this.ASCII_mode = ASCII_mode;
    }

    private stastic stt = new stastic();
    private IO my_save = new IO();

    public noteFrame() throws HeadlessException {

        super("快乐笔记");
        this.initComponents();
        dim = this.getToolkit().getScreenSize();// 获取屏幕分辨率
        this.setSize(dim.width * 2 / 3, dim.height * 2 / 3);// 设置窗口大小
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    private void initComponents() {
        my_page = new page();
        header_bg = new ImageIcon("images\\blue.jpg");
        jmb = new JMenuBar();
        this.setJMenuBar(jmb);
        fontStyle[0] = 0;
        fontStyle[1] = 0;
        style = 0;
        //菜单
        jmFile = new JMenu("文件");
        jmEdit = new JMenu("编辑");
        jmTool = new JMenu("工具");
        jmHelp = new JMenu("帮助");
        //文件
        String[] jmFileStr = {"新建", "打开", "保存", "另存为","设置", "关闭"};
        jmtFiles = new JMenuItem[jmFileStr.length];
        for (int i = 0; i < jmFileStr.length; i++){
            jmtFiles[i] = new JMenuItem(jmFileStr[i]);
            jmtFiles[i].addActionListener(this);
            jmFile.add(jmtFiles[i]);
            if(i == 3 || i == 4) jmFile.addSeparator();
        }
        jmtFiles[2].setEnabled(false);
        String[] jmEditStr = {"撤销", "剪切 ", "复制 ", "粘贴 ", "清空文本", "查找" };
        jmtEdits = new JMenuItem[jmEditStr.length];
        for (int i = 0; i < jmEditStr.length; i++) {
            jmtEdits[i] = new JMenuItem(jmEditStr[i]);
            jmtEdits[i].addActionListener(this);
            jmEdit.add(jmtEdits[i]);
            if(i == 3 || i == 4) jmEdit.addSeparator();
        }
        jmtLineWrap = new JCheckBoxMenuItem("自动换行");
        jmtAbout = new JMenuItem("关于");
        jmtTool = new JCheckBoxMenuItem("打开工具栏");

        // 菜单添加到 菜单栏中
        jmb.add(jmFile);
        jmb.add(jmEdit);
        jmb.add(jmHelp);
        jmb.add(jmTool);
        jmEdit.add(jmtLineWrap);
        jmHelp.add(jmtAbout);
        jmTool.add(jmtTool);

        //JToolBar
        jtb = new JToolBar();
        jtb.setBackground(Color.black);
        jtb.setLayout(new FlowLayout(FlowLayout.LEFT));

        // JTextArea
        content_bg = new ImageIcon("images\\background.jpg");
        jta = new JTextArea(20,50){
            {setOpaque(false);}
            protected void paintComponent(Graphics g){
                g.drawImage(content_bg.getImage(), 0,0,this.getWidth(), this.getHeight(), this);
                super.paintComponent(g);
            }
        };


        font = jta.getFont();

        jta.setSelectedTextColor(Color.blue);
        jta.setSelectionColor(Color.white);
        jta.setSelectionStart(0);

        this.getContentPane().add(new JScrollPane(jta));
        // 设置自动换行
        jta.setLineWrap(true);
        jta.getDocument().addUndoableEditListener(new UndoableEditListener() {
            @Override
            public void undoableEditHappened(UndoableEditEvent e) {
                undoManager.addEdit(e.getEdit());
            }
        });

        // p1
        p1 = new JPanel();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        String[] fontsName = ge.getAvailableFontFamilyNames();
        jcbFont = new JComboBox<String>(fontsName);
        for (int i = 0; i < fontsName.length; i++) {
            if(fontsName[i].equals("宋体")){
                jcbFont.setSelectedIndex(i);
                break;
            }
        }
        jlFont = new JLabel("字体: ");
        jlFont.setForeground(Color.white);
        p1.setOpaque(false); //面板变透明
        jcbFont.addActionListener(this);
        p1.add(jlFont);
        p1.add(jcbFont);
        jtb.add(p1);

        // 创建面板2
        p2 = new JPanel();
        String sizeStr[] = new String[60];
        for (int i = 0; i < 60; i++) {
            sizeStr[i] = String.valueOf(i + 1);
        }
        jlSize = new JLabel(" 字号:");
        jlSize.setForeground(Color.white);
        jcbSize = new JComboBox<String>(sizeStr);
        p2.setOpaque(false);
        p2.add(jlSize);
        jcbSize.setEditable(false);
        jcbSize.setSelectedIndex(15);// 设置默认选中项为第15项
        jcbSize.setEditable(false);
        jcbSize.addActionListener(this);
        p2.add(jcbSize);
        jtb.add(p2);

        // 创建面板3
        p3 = new JPanel();
        jbColor = new JButton("字体颜色");
        jbColor.setForeground(Color.white);
        jcbBold = new JCheckBox("粗体");
        jcbBold.setForeground(Color.white);
        jcbItalic = new JCheckBox("斜体");
        jcbItalic.setForeground(Color.white);
        jlStyle = new JLabel(" 字型 :");
        jlStyle.setForeground(Color.white);
        jlColor = new JLabel("▇ ");
        jbClear = new JButton("清空文本");
        p3.setOpaque(false);// 设置面板为透明
        jcbItalic.setOpaque(false);
        jcbBold.setOpaque(false);
        jbColor.setForeground(color);
        jcbBold.addActionListener(this);
        jcbItalic.addActionListener(this);
        p3.add(jbColor);
        p3.add(jlColor);
        p3.add(jlStyle);
        p3.add(jcbBold);
        p3.add(jcbItalic);
        p3.add(jbClear);
        jtb.add(p3);
        this.getContentPane().add(jtb, "North");// 把JToolBar添加到面板的北边

        // 统计字数
        textSize = stt.count(jta.getText());
        fileSize = 0;
        jlStastic = new JLabel("字数：" + textSize + " 文件大小" + fileSize + " B");
        jlStastic.setBackground(color.ORANGE);
        jlStastic.setOpaque(true);
        this.getContentPane().add(jlStastic, "South");

        jmtLineWrap.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (jmtLineWrap.isSelected()) {
                    jta.setLineWrap(true);
                } else {
                    jta.setLineWrap(false);
                }
            }
        });
        jbClear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == jmtEdits[5] || e.getSource() == jbClear) {// "清空"事件
                    jta.setText("");
                }
            }
        });

        jmtAbout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == jmtAbout) {
                    JOptionPane.showMessageDialog(null,
                            "快乐笔记\n版本：1.0\n设计：Aili", "关于", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        jbColor.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == jbColor) {// 设置字体颜色事件
                    color = JColorChooser.showDialog(null, "选择字体颜色", color);
                    jta.setForeground(color);// 设置文本域的颜色
                    jlColor.setForeground(color);// 显示字体的颜色
                    my_page.setFontColor(color);
                    int[] fontColor = {color.getRed(), color.getGreen(), color.getBlue()};
                }
            }
        });
        jtb.setVisible(false);
        jmtTool.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(jmtTool.isSelected())
                    jtb.setVisible(true);
                else jtb.setVisible(false);
            }
        });
        jta.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                isUpdated = true;
                my_page.setMainBuffer(jta.getText());
                textSize = stt.count(jta.getText());
                jlStastic.setText("字数：" + textSize + " 文件大小" + fileSize + " B");
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                my_page.setMainBuffer(jta.getText());
                textSize = stt.count(jta.getText());
                jlStastic.setText("字数：" + textSize + " 文件大小" + fileSize + " B");
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
            }
        });
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if (isSaved == false && isUpdated) {
                    if (JOptionPane.showConfirmDialog(noteFrame.this, "文件尚未保存，需要保存吗？", "提示", JOptionPane.YES_NO_OPTION,
                            JOptionPane.INFORMATION_MESSAGE) == JOptionPane.OK_OPTION) {
                        IO.getInstance().saveFileAs();
                    }
                }
                if (JOptionPane.showConfirmDialog(null, "确定要提出MyEditor吗？", "退出", JOptionPane.YES_NO_OPTION,
                        JOptionPane.INFORMATION_MESSAGE) == JOptionPane.OK_OPTION) {
                    System.exit(0);
                } else {
                    noteFrame.this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
                }
            }
        });

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(Reading_file == false){
            String fontName = jcbFont.getSelectedItem().toString();
            my_page.setFontFamily(jcbFont.getSelectedIndex());
            int size = Integer.parseInt(jcbSize.getSelectedItem().toString());
            my_page.setFontSize(size);
            if(jcbBold.isSelected() && (!jcbItalic.isSelected())){
                fontStyle[0] = 1;
                fontStyle[1] = 0;
                style = 1;
            }
            if ((!jcbBold.isSelected()) && jcbItalic.isSelected()) {
                fontStyle[0] = 0;
                fontStyle[1] = 1;
                style = 2;
            }
            if((!jcbBold.isSelected()) && (!jcbItalic.isSelected())){
                fontStyle[0] = 0;
                fontStyle[1] = 0;
                style = 0;
            }
            if(jcbBold.isSelected() && jcbItalic.isSelected()){
                fontStyle[0] = 1;
                fontStyle[1] = 1;
                style = 3;
            }
            System.out.println("flag3");
            my_page.setFontStyle(style);
            jta.setFont(new Font(fontName, style, size));
        }

        if (e.getSource() == jmtFiles[0]) {// "新建“事件
            IO.getInstance().newFile(path);
        }
        else if(e.getSource() == jmtFiles[1]){// "打开事件“
            Reading_file = true;
            IO.getInstance().openFile();
            System.out.println("after open");
            loadPage(my_page);
            Reading_file = false;
        }
        else if(e.getSource() == jmtFiles[2]){// "保存"事件
            IO.getInstance().saveFile(path);
        }
        else if(e.getSource() == jmtFiles[3]){// "另存为“ 事件
            IO.getInstance().saveFileAs();
        }
        else if (e.getSource() == jmtFiles[5]) {// “退出”事件
            if (isSaved == false && isUpdated) {
                if (JOptionPane.showConfirmDialog(this, "文件尚未保存，需要保存吗？", "提示", JOptionPane.YES_NO_OPTION,
                        JOptionPane.INFORMATION_MESSAGE) == JOptionPane.OK_OPTION) {
                        IO.getInstance().saveFile(path);
                }
            }
            if (JOptionPane.showConfirmDialog(this, "确定要提出Edit++吗？", "退出", JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE) == JOptionPane.OK_OPTION) {
                System.exit(0);
            }
        }
        else if(e.getSource() == jmtEdits[0]){ // 撤销
            undoManager.undo();
        }
        else if(e.getSource() == jmtEdits[1]){ // 剪切
            jta.cut();
        }
        else if(e.getSource() == jmtEdits[2]) { // 复制
            jta.copy();
        }
        else if(e.getSource() == jmtEdits[3]) { // 复制
            jta.paste();
        }
        else if(e.getSource() == jmtEdits[4]) { // 清空
            jta.setText("");
        }
        else if(e.getSource() == jmtEdits[5]) { // 复制
            Searcher s = new Searcher();
        }

    }
    public void loadPage(page cur_page){
        System.out.println("In the loadPage");
        jta.setText(cur_page.getMainBuffer());
        jta.setForeground(cur_page.getFontColor());
        jlColor.setForeground(cur_page.getFontColor());
        jcbFont.setSelectedIndex(cur_page.getFontFamily());
        jcbSize.setSelectedIndex(cur_page.getFontSize());
        style = cur_page.getFontStyle();
        System.out.println("check the syle");
        System.out.println(style);
        if(style == 0){
            fontStyle[0] = fontStyle[1] = 0;
            jcbBold.setSelected(false);
            jcbItalic.setSelected(false);
        }else if(style == 1){
            System.out.println("yes i should work, but not");
            fontStyle[0] = 1; fontStyle[1] = 0;
            jcbBold.setSelected(true);
            jcbItalic.setSelected(false);
        }else if(style == 2){
            fontStyle[0] = 0; fontStyle[1] = 1;
            jcbBold.setSelected(false);
            jcbItalic.setSelected(true);
        }else if(style == 3){
            fontStyle[0] = fontStyle[1] = 1;
            jcbBold.setSelected(true);
            jcbItalic.setSelected(true);
        }
        String fontName = jcbFont.getSelectedItem().toString();
        int size = Integer.parseInt(jcbSize.getSelectedItem().toString());
        jta.setFont(new Font(fontName, style, size));
    }
    private boolean isSaved = false, isUpdated = false, isM = false;

    public void setIsSaved(boolean isSaved) {
        this.isSaved = isSaved;
    }

    public JMenuItem getJmtFiles(int i) {
        return jmtFiles[i];
    }

    public JTextArea getJta() {
        return jta;
    }

    public static noteFrame getInstance(){
        return cur_noteframe;
    }
}
