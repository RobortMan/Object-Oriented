package Main;


import com.alibaba.fastjson.annotation.JSONField;

import java.awt.*;

public class page {

    public page(){
    }
    // id
    @JSONField(name = "PAGEID")
    int his_index;
    // 存放所有字符的缓存器
    @JSONField(name = "CONTENT")
    private String mainBuffer;

    // 排版信息
    @JSONField(name = "FONTFAMILY")
    int fontFamily;
    @JSONField(name = "FONTCOLOR")
    Color fontColor;
    @JSONField(name = "FONTSyle")
    int fontStyle;
    @JSONField(name = "FONTSIZE")
    int fontSize;


    public int getFontSize() {
        return fontSize;
    }

    public void setFontSize(int fontSize) {
        this.fontSize = fontSize;
    }


    public void setMainBuffer(String mainBuffer) {
        this.mainBuffer = mainBuffer;
    }

    public void replaceBuffer(char oldChar, char newChar){ this.mainBuffer = this.mainBuffer.replace(oldChar, newChar); }
    public String getMainBuffer() {
        return mainBuffer;
    }


    public int getFontFamily() {
        return fontFamily;
    }

    public void setFontFamily(int fontFamily) {
        this.fontFamily = fontFamily;
    }

    public Color getFontColor() {
        return fontColor;
    }

    public void setFontColor(Color fontColor) {
        this.fontColor = fontColor;
    }

    public int getFontStyle() {
        return fontStyle;
    }

    public void setFontStyle(int fontStyle) {
        System.out.println("init");
        System.out.println(fontStyle);
        this.fontStyle = fontStyle;
        System.out.println(this.fontStyle);

    }
}
