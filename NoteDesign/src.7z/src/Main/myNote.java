package Main;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.util.ArrayList;
import java.util.List;

public class myNote {
    private static myNote mainNote = new myNote();
    private static final JFileChooser jfc = new JFileChooser();
    private static FileNameExtensionFilter txtFilter, edtFilter, javaFilter,xmlFilter;

    public static void main(String[] args) {
        page mainPage = new page();

        shoutcutKey cur_sck = shoutcutKey.getInstance();
        cur_sck.addkeylistener();
        noteFrame ntf = noteFrame.getInstance();
        ntf.getJta().setText("Welcome to use this notebook!!!\n" +
                "it is simple to use this notebook!\n" +
                "I give some useful function that you may like.\n" +
                "First you can use Ctrl+0 to change to the M-mode\n" +
                "press Ctrl+1 to change to ASCII-mode\n");
        IO cur_save = new IO();
//        historyList his = new historyList();
//        cur_save.convert2json();
    }

    public static JFileChooser getJfc() {
        txtFilter = new FileNameExtensionFilter("txt(文本文件)", "txt");
        edtFilter = new FileNameExtensionFilter("edt(加密的文本文件)", "edt");
        javaFilter = new FileNameExtensionFilter("java(Java源代码)", "java");
        xmlFilter = new FileNameExtensionFilter("xml(扩展标记语言)", "xml");
        jfc.setFileFilter(edtFilter);
        jfc.setFileFilter(javaFilter);
        jfc.setFileFilter(xmlFilter);
        jfc.setFileFilter(txtFilter);
        jfc.setAcceptAllFileFilterUsed(false);
        return jfc;
    }

    public static FileNameExtensionFilter getTxtFilter() {
        return txtFilter;
    }


    public static myNote getInstance(){
        return mainNote;
    }


}
